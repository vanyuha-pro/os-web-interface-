
var i = 0;

var mvLeft = false;
var mvRight = false;

var rotKorp = 0;
var rotKoles = 0;

var rotKolesSpeed = 3;
var rotKorpSpeed = .9;
var rotKorpMove = 1.06;

var maxKorpRot = 93.2;

var moveSpeed = 2;
var moveFallSpeed = 1;
var poseX =  0;

var scrollX = 0;

var winW = 0;
var winH = 0;

var fall = false;
var reStarted = false;

var rekord = -1000;

var cm = 0;

var started = false;

znv = 0;
znvM = 1;

window.addEventListener("resize", function() { winSize(); reStart(); }, false);

document.addEventListener('touchstart', function(event) {
	for(i=0; i<event.touches.length; i++) {
		if(event.touches[i].pageX > winW/2) mvRight = true;
		else mvLeft = true;
	}
	event.preventDefault();
}, false);
document.addEventListener('touchend', function() {
	mvRight = false;
	mvLeft = false;
	event.preventDefault();
}, false);

window.addEventListener("load", function() {
	
	if(localStorage.getItem("used") == "true") rekord = parseInt(localStorage.getItem("rekord"));
	
	var robot = document.getElementById("robot");
	var korpus = document.getElementById("korpus");
	var koleso = document.getElementById("koleso");
	var ground = document.getElementById("ground");
	var flagStart = document.getElementById("flag_start");
	var flagRekord = document.getElementById("flag_rekord");
	var zanaves = document.getElementById("zanaves");
	var zanavesMain = document.getElementById("zanavesMain");
	//flagRekord.style.left = rekord + 500 + "px";
	var text = document.getElementById("text");
	
	window.addEventListener("keydown", function(e) {
		
		if(e.which == 65) {mvLeft = true;}
		if(e.which == 68) {mvRight = true;}
		if(e.which == 37) {mvLeft = true;}
		if(e.which == 39) {mvRight = true;}
		
	}, false);
	
	window.addEventListener("keyup", function(e) {
		
		if(e.which == 65) {mvLeft = false;}
		if(e.which == 68) {mvRight = false;}
		if(e.which == 37) {mvLeft = false;}
		if(e.which == 39) {mvRight = false;}
		
	}, false);
	
	winSize();
	anim();
	
	window.setTimeout( function() { started = true }, 3000);
	
}, false);

ax = 0;
ay = 0;
	
function anim() {


if(vpr) ax += 5;
if(vlevo) ax -= 5;




ax *= 0.9;
x += ax;











	       document.getElementById('k').style.left = x+'px';
	       
 if(x < 0) {
x = 0;
if(ax < 2 && ax > -10) ax = 0;
else ax *= -0.5;

}
	       
	       if(x > document.documentElement.clientWidth - 300 ) {
x = document.documentElement.clientWidth - 300;
if(ax < 2 && ax > -10) ax = 0;
else ax *= -0.5;
}
	       
        if(y > document.documentElement.clientHeight - 100 ) {
y = document.documentElement.clientHeight - 100;
if(ay < 2 && ay > -10) ay = 0;
else ay *= -0.5;
}
    

    
        if(vniz) ay += 5;
if(ver) ay -= 5;

ay *= 0.9;
y += ay;

if(y < 0 ) {
y = 0;
if(ax < 2 && ay > -10) ay = 0;
else ay *= -0.5;
}
document.getElementById('k').style.top = y+'px';
        
        
        
        window.setTimeout(function() { anim() }, 41);
        
      }
      





document.addEventListener('DOMContentLoaded', function(f) {

anim();

});
