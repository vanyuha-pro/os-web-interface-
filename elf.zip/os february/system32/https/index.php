<? php
phpinfo();

?>
