import http.server
import socketserver
import webbrowser
PORT = 8000

Handler = http.server.SimpleHTTPRequestHandler
webbbrowser.get().open("http://localhost:8000")
with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print("serving at port", PORT)
    httpd.serve_forever()
