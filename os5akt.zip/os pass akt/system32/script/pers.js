 
 		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("obst").addEventListener("click", function() {
        document.getElementById('obst').style.opacity = "20%";
                document.getElementById('obvista').style.opacity = "100%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
                document.getElementById('obos').style.opacity = "100%";
				document.getElementById('body').style.backgroundImage = "url(system32/css/img/body.jpg)";
localStorage.setItem('bo', JSON.stringify({
    'h': document.getElementById('body').style.backgroundImage,
                                              'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity,
    'ob5': document.getElementById('obos').style.opacity
}))
			});
		});
		
        	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("obst2").addEventListener("click", function() {

				document.getElementById('body').style.backgroundImage = "url(system32/css/img/body2.jpg)";
                document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "100%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "20%";
localStorage.setItem('bo', JSON.stringify({
    'h': document.getElementById('body').style.backgroundImage,
                                              'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity,
    'ob5': document.getElementById('obst').style.opacity
}))
			});
		});
        
        
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("obvista").addEventListener("click", function() {

				document.getElementById('body').style.backgroundImage = "url(system32/css/img/vista.jpg)";
                        document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "20%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
                document.getElementById('obos').style.opacity = "100%";
localStorage.setItem('bo', JSON.stringify({
    'h': document.getElementById('body').style.backgroundImage,
                                              'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity,
    'ob5': document.getElementById('obst').style.opacity
}))
			});
		});
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("obbl").addEventListener("click", function() {
        document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "100%";
                document.getElementById('obbl').style.opacity = "20%";
                document.getElementById('obst2').style.opacity = "100%";
                document.getElementById('obos').style.opacity = "100%";
				document.getElementById('body').style.backgroundImage = "url(system32/css/img/i.webp)";
localStorage.setItem('bo', JSON.stringify({
    'h': document.getElementById('body').style.backgroundImage,
    'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity,
    'ob5': document.getElementById('obst').style.opacity
}))
			});
		});
                
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("obos").addEventListener("click", function() {
        document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "100%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
                document.getElementById('obos').style.opacity = "20%";
				document.getElementById('body').style.backgroundImage = "url(system32/css/img/body4.jpg)";
localStorage.setItem('bo', JSON.stringify({
    'h': document.getElementById('body').style.backgroundImage,
    'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity,
    'ob5': document.getElementById('obos').style.opacity
}))
			});
		});
 		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("redp").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "red";

			});
		});
 
 
 
 
  mouseX = 0;
      mouseY = 0;
      shiftX = 0;
      shiftY = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);
        mouseX = e.clientX;
        mouseY = e.clientY;
      });
      
      blockHold = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('pers2').addEventListener('mousedown', function(e) {
          blockHold = true;
          x = parseInt(document.getElementById('pers2').style.left);
          y = parseInt(document.getElementById('pers2').style.top);
          shiftX = e.clientX - x;
          shiftY = e.clientY - y;
        });
        anim();
      });
      
      document.addEventListener('mouseup', function() { blockHold = false });
      

      function anim() {
        
        if(blockHold) {
          document.getElementById('pers2').style.left = (mouseX-shiftX) + 'px';
          document.getElementById('pers2').style.top = (mouseY-shiftY) + 'px';
        }
        
        window.setTimeout(function() { anim() }, 40);
      }



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("red").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundColor = "red";
				document.getElementById('clock').style.backgroundColor = "red";
				document.getElementById('vr').style.backgroundColor = "red";
                 document.getElementById('uvedd').style.backgroundColor = "red";
				document.getElementById('clock3').style.backgroundColor = "red";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("blue").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundImage = "none";
				document.getElementById('clock').style.backgroundColor = "blue";
                 document.getElementById('pz').style.backgroundColor = "blue";
                    document.getElementById('vr').style.backgroundImage = "none";
                     document.getElementById('vr').style.backgroundColor = "blue";
                      document.getElementById('uvedd').style.backgroundColor = "blue";
                      document.getElementById('vr').style.backgroundSize = "contain";
				document.getElementById('clock3').style.backgroundColor = "blue";

			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("yellow").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundColor = "yellow";
				document.getElementById('clock').style.backgroundColor = "yellow";
				document.getElementById('vr').style.backgroundColor = "yellow";
                 document.getElementById('uvedd').style.backgroundColor = "yellow";
				document.getElementById('clock3').style.backgroundColor = "yellow";

			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("redt").addEventListener("click", function() {
				document.getElementById('clock').style.backgroundColor = "#e0e0e0";
				document.getElementById('vr').style.backgroundColor = "#e0e0e0";
				document.getElementById('clock3').style.backgroundColor = "#e0e0e0";
				document.getElementById('mp').style.backgroundColor = "#e0e0e0";
				document.getElementById('body').style.backgroundColor = "none";
                document.getElementById('clock3').style.backgroundImage = "none";
                document.getElementById('clock').style.backgroundImage = "none";
                document.getElementById('clock2').style.backgroundImage = "none";
                 document.getElementById('uvedd').style.backgroundColor = "#e0e0e096";
				document.getElementById('p').style.backgroundColor = "darkgray";
				document.getElementById('body').style.backgroundImage = "url(system32/css/img/vista.jpg)";
				     document.getElementById('p').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundColor = "#e0e0e0";
                document.getElementById('vr').style.backgroundImage = "none";
                
                document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "20%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
localStorage.setItem('bo', JSON.stringify({
    'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity
}))
                
                localStorage.setItem('tem', JSON.stringify({
    'bg': document.getElementById('pz').style.backgroundColor,
    'img': document.getElementById('pz').style.backgroundImage,
    'r': document.getElementById('pz').style.backgroundRepeat,
      'pz':          document.getElementById('pz').style.backgroundSize,
		'k':  		document.getElementById('vr').style.backgroundImage,
        'l':          document.getElementById('vr').style.backgroundSize,
                                                                   'p':          document.getElementById('vr').style.backgroundColor,
		't':  		document.getElementById('clock').style.backgroundColor,
		'c':  		document.getElementById('clock3').style.backgroundColor,
		'n':  		document.getElementById('mp').style.backgroundColor,
         's':         document.getElementById('mp').style.Opacity,
		'm':  		document.getElementById('body').style.backgroundColor,
		'z':  		document.getElementById('p').style.backgroundImage,
         'd':         document.getElementById('body').style.backgroundImage,
         'q':         document.getElementById('body').style.backgroundSize,
         'm2':         document.getElementById('body').style.backgroundPosition,
          'o':        document.getElementById('p').style.backgroundSize,
           'op':        document.getElementById('p').style.backgroundColor,
           'kj':        document.getElementById('uvedd').style.backgroundColor
     
    
}))
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("bluet").addEventListener("click", function() {
				
				document.getElementById('clock').style.backgroundImage = "none";
				document.getElementById('vr').style.backgroundImage = "none";
                document.getElementById('vr').style.backgroundSize = "cover";
                document.getElementById('clock3').style.backgroundColor = "blue";
				document.getElementById('clock3').style.backgroundImage = "none";
                document.getElementById('clock').style.backgroundColor = "blue";
				document.getElementById('mp').style.backgroundColor = "lightblue";
                document.getElementById('mp').style.backgroundImage = "none";
                
                document.getElementById('body').style.backgroundSize = "cover";
                 document.getElementById('uvedd').style.backgroundColor = "blue";
				document.getElementById('body').style.backgroundColor = "none";
                document.getElementById('body').style.backgroundImage = "url(system32/css/img/body.jpg)";
				document.getElementById('p').style.backgroundColor = "green";
                document.getElementById('p').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundColor = "blue";
                document.getElementById('vr').style.backgroundColor = "blue";
        
                       
                                document.getElementById('obst').style.opacity = "20%";
                document.getElementById('obvista').style.opacity = "100%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
localStorage.setItem('bo', JSON.stringify({

    'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity
}))

                localStorage.setItem('tem', JSON.stringify({
    'bg': document.getElementById('pz').style.backgroundColor,
    'img': document.getElementById('pz').style.backgroundImage,
    'r': document.getElementById('pz').style.backgroundRepeat,
      'pz':          document.getElementById('pz').style.backgroundSize,
		'k':  		document.getElementById('vr').style.backgroundImage,
        'l':          document.getElementById('vr').style.backgroundSize,
		't':  		document.getElementById('clock').style.backgroundColor,
		'c':  		document.getElementById('clock3').style.backgroundColor,
		'n':  		document.getElementById('mp').style.backgroundColor,
                                                            'p':          document.getElementById('vr').style.backgroundColor,
         's':         document.getElementById('mp').style.Opacity,
		'm':  		document.getElementById('body').style.backgroundColor,
		'z':  		document.getElementById('p').style.backgroundImage,
         'd':         document.getElementById('body').style.backgroundImage,
          'o':        document.getElementById('p').style.backgroundSize,
           'op':        document.getElementById('p').style.backgroundColor,
           'kj':        document.getElementById('uvedd').style.backgroundColor,
                                                           'd':         document.getElementById('body').style.backgroundImage
}))
                
			});
		});

		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("stt").addEventListener("click", function() {
            
                document.getElementById('pz').style.backgroundColor = "none";
				document.getElementById('pz').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('pz').style.backgroundRepeat = "repeat-x";
                document.getElementById('pz').style.backgroundSize = "contain";
				document.getElementById('vr').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('vr').style.backgroundSize = "contain";
				document.getElementById('clock').style.backgroundColor = "black";
				document.getElementById('clock3').style.backgroundColor = "black";
				document.getElementById('mp').style.backgroundColor = "black";
                document.getElementById('mp').style.Opacity = "0.5";
				document.getElementById('body').style.backgroundColor = "none";
				document.getElementById('p').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('body').style.backgroundImage = "url(system32/css/img/vista.jpg)";
                document.getElementById('p').style.backgroundSize = "contain";
                document.getElementById('uvedd').style.backgroundColor = "black";
                
                document.getElementById('obst').style.opacity = "100%";
                document.getElementById('obvista').style.opacity = "20%";
                document.getElementById('obbl').style.opacity = "100%";
                document.getElementById('obst2').style.opacity = "100%";
localStorage.setItem('bo', JSON.stringify({

    'ob1': document.getElementById('obvista').style.opacity,
    'ob2': document.getElementById('obbl').style.opacity,
    'ob3': document.getElementById('obst2').style.opacity,
    'ob4': document.getElementById('obst').style.opacity
}))

localStorage.setItem('tem', JSON.stringify({
    'bg': document.getElementById('pz').style.backgroundColor,
    'img': document.getElementById('pz').style.backgroundImage,
    'r': document.getElementById('pz').style.backgroundRepeat,
      'pz':          document.getElementById('pz').style.backgroundSize,
		'k':  		document.getElementById('vr').style.backgroundImage,
        'l':          document.getElementById('vr').style.backgroundSize,
		't':  		document.getElementById('clock').style.backgroundColor,
                                            'p':          document.getElementById('vr').style.backgroundColor,
		'c':  		document.getElementById('clock3').style.backgroundColor,
		'n':  		document.getElementById('mp').style.backgroundColor,
         's':         document.getElementById('mp').style.Opacity,
		'm':  		document.getElementById('body').style.backgroundColor,
		'z':  		document.getElementById('p').style.backgroundImage,
         'd':         document.getElementById('body').style.backgroundImage,

          'o':        document.getElementById('p').style.backgroundSize,
          'op':        document.getElementById('p').style.backgroundColor,
          'kj':        document.getElementById('uvedd').style.backgroundColor

}))

        
			});
		});
		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("bluep").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "lightblue";

			});
		});
        /*
        	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pass4").addEventListener("click", function() {

				document.getElementById('ifr').src = 'C:';

			});
            });*/





		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("yellowp").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "yellow";

			});
		});
		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pers3").addEventListener("click", function() {
				document.getElementById('pers2').style.display = "none";
                            document.getElementById("pk7").style.display = 'block';
document.getElementById("otkrpers").style.display = 'none';
				
			});
		});
        
        
        
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd7").addEventListener("click", function() {
				document.getElementById('pers2').style.display = "block";
				     document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
                        document.getElementById("otkrpers").style.display = "block";

document.getElementById("pk7").style.display = "none";
			});
		});
                
                
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk7").addEventListener("click", function() {
               
			document.getElementById('pers2').style.display = "block";
             document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
            document.getElementById("otkrpers").style.display = "block";

document.getElementById("pk7").style.display = "none";
			});
		});

                
   mouseX3 = 0;
      mouseY3 = 0;
      shiftX3 = 0;
      shiftY3 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX3 = e.clientX;
        mouseY3 = e.clientY;
      });
      
      bloc = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('kstr').addEventListener('mousedown', function(e) {
          bloc = true;
          x = parseInt(document.getElementById('kstr').style.left);
          y = parseInt(document.getElementById('kstr').style.top);
          shiftX3 = e.clientX - x;
          shiftY3 = e.clientY - y;
        });
        anim4();
      });
      
      document.addEventListener('mouseup', function() { bloc = false });
      
   
      function anim4() {
        
        if(bloc) {
          document.getElementById('kstr').style.left = (mouseX3-shiftX3) + 'px';
          document.getElementById('kstr').style.top = (mouseY3-shiftY3) + 'px';
        }
        
        window.setTimeout(function() { anim4() }, 40);
      }

      
      
      
      
      
      
      
              	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("usp").addEventListener("click", function() {
                document.getElementById('usp').style.opacity = "20%";
                document.getElementById('usp2').style.opacity = "100%";
                document.getElementById('usp3').style.opacity = "100%";
                document.getElementById('usp4').style.opacity = "100%";
				document.getElementById('userpic').style.backgroundImage = "url(system32/userpic/index.png)";
                document.getElementById('logo').style.backgroundImage = "url(system32/userpic/index.png)";
localStorage.setItem('us', JSON.stringify({
    'ur': document.getElementById('userpic').style.backgroundImage,
        'usp2': document.getElementById('usp2').style.opacity,
    'usp': document.getElementById('usp').style.opacity,
    'usp3': document.getElementById('usp3').style.opacity,
                                          'usp4': document.getElementById('usp4').style.opacity,
    'l': document.getElementById('logo').style.backgroundImage
}))
			});
		});
                        	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("usp2").addEventListener("click", function() {

				document.getElementById('userpic').style.backgroundImage = "url(system32/userpic/index2.jpg)";
                document.getElementById('logo').style.backgroundImage = "url(system32/userpic/index2.jpg)";
                document.getElementById('usp2').style.opacity = "20%";
                document.getElementById('usp').style.opacity = "100%";
                document.getElementById('usp3').style.opacity = "100%";
                document.getElementById('usp4').style.opacity = "100%";
localStorage.setItem('us', JSON.stringify({
    'ur': document.getElementById('userpic').style.backgroundImage,
        'usp2': document.getElementById('usp2').style.opacity,
    'usp': document.getElementById('usp').style.opacity,
    'usp3': document.getElementById('usp3').style.opacity,
                                          'usp4': document.getElementById('usp4').style.opacity,
    'l': document.getElementById('logo').style.backgroundImage
}))
			});
		});
                                    	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("usp3").addEventListener("click", function() {

				document.getElementById('userpic').style.backgroundImage = "url(system32/userpic/index3.png)";
                document.getElementById('logo').style.backgroundImage = "url(system32/userpic/index3.png)";
                document.getElementById('usp3').style.opacity = "20%";
                document.getElementById('usp').style.opacity = "100%";
                document.getElementById('usp2').style.opacity = "100%";
                document.getElementById('usp4').style.opacity = "100%";
localStorage.setItem('us', JSON.stringify({
    'ur': document.getElementById('userpic').style.backgroundImage,
                                          'l': document.getElementById('logo').style.backgroundImage,
    'usp2': document.getElementById('usp2').style.opacity,
    'usp': document.getElementById('usp').style.opacity,
    'usp3': document.getElementById('usp3').style.opacity,
    'usp4': document.getElementById('usp4').style.opacity
}))
			});
		});
                                    	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("usp4").addEventListener("click", function() {

				document.getElementById('userpic').style.backgroundImage = "url(system32/userpic/bp.png)";
                document.getElementById('logo').style.backgroundImage = "url(system32/userpic/bp.png)";
                document.getElementById('usp3').style.opacity = "100%";
                document.getElementById('usp').style.opacity = "100%";
                document.getElementById('usp2').style.opacity = "100%";
                document.getElementById('usp4').style.opacity = "20%";
localStorage.setItem('us', JSON.stringify({
    'ur': document.getElementById('userpic').style.backgroundImage,
                                          'l': document.getElementById('logo').style.backgroundImage,
    'usp2': document.getElementById('usp2').style.opacity,
    'usp': document.getElementById('usp').style.opacity,
    'usp3': document.getElementById('usp3').style.opacity,
    'usp4': document.getElementById('usp4').style.opacity
}))
			});
		});
