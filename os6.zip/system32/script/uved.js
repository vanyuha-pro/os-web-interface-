		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("dk1").addEventListener("click", function() {

				document.getElementById("div1").style.display = 'none';
document.getElementById("div2").style.display = 'block';
			});
		});

        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("dk2").addEventListener("click", function() {

				document.getElementById("div2").style.display = 'none';
document.getElementById("div3").style.display = 'block';
			});
		});

        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("prog4").addEventListener("click", function() {

				document.getElementById("prog3").style.display = 'none';
			});
		});
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("dk3").addEventListener("click", function() {
				document.getElementById("div3").style.display = 'none';
                document.getElementById("divdiv").style.display = 'none';
                document.getElementById("ifr").style.width = '100%';
			});
		});

                
                
                        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("passakt").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'block';
         
			});
		});     
                                
                                
                            		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("passz").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'none';
         
			});
            
            
            
            
    
            
            
            
            
            
            
            
		});                             
