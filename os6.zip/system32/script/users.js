
	document.addEventListener('DOMContentLoaded', function() {
var p

document.getElementById('newpassb').addEventListener('click', function() {

p = document.getElementById("newpass").value;
localStorage.setItem('passw', p);
});

var nik;



document.getElementById('nib').addEventListener('click', function() {
    nik = document.getElementById('ni').value;

    document.getElementById('u2').value =  nik;
    
    localStorage.setItem('user', document.getElementById('u2').value);
});
});
	
	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("user").addEventListener("click", function() {
				
				document.getElementById('pyuse').style.display = "block";
                     document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";

document.getElementById("otkruser").style.display = 'block';
			});
		});
document.addEventListener('DOMContentLoaded', function() {
/*document.getElementById('bootm').style.display = "block";
document.getElementById('page').style.display = "none";
document.getElementById('vets4').style.display = "none";
document.getElementById("bootb").addEventListener("click", function() {
document.getElementById('bootm').style.display = "none";
*/

    document.getElementById('page').style.display = "none";
 document.getElementById('vets4').style.display = "block";
window.setTimeout(function(){ 
document.getElementById("vets4").style.display = "block";
document.getElementById("vets").style.display = "none";
     if(localStorage.getItem('us')) {
     user = JSON.parse(localStorage.getItem('us')  );
       document.getElementById('userpic').style.backgroundImage = user['ur']
       document.getElementById('logo').style.backgroundImage = user['l']
    document.getElementById('usp2').style.opacity = user['usp2']
    document.getElementById('usp3').style.opacity = user['usp3']
    document.getElementById('usp').style.opacity = user['usp']
     }
     
             	 if(localStorage.getItem('volume')) {
                  vol = JSON.parse(localStorage.getItem('volume')  );
                  document.getElementById('audio').volume = vol['a1']
                  document.getElementById('audio2').volume = vol['a2']
                  document.getElementById('audio3').volume = vol['a3']
                  document.getElementById('audio4').volume = vol['a4']
                  document.getElementById('audio5').volume = vol['a5']
         }
     
},1000);
window.setTimeout(function(){ 
document.getElementById("vets4").style.display = "none";
p = localStorage.getItem('passw');
document.getElementById("vets").style.display = "block";

},2000);


  window.setTimeout(function(){ 
        

document.getElementById("vets").style.display = "none";


document.getElementById('page').style.display = "block";
	document.getElementById('u2').value = localStorage.getItem('user');
    	document.getElementById('gadj').style.display = localStorage.getItem('gad');;

     
     
    if(localStorage.getItem('tem')) {
     tema = JSON.parse(localStorage.getItem('tem')  );
     document.getElementById('body').style.backgroundImage = tema['d']
    document.getElementById('pz').style.backgroundColor = tema['bg']
    document.getElementById('pz').style.backgroundImage = tema['img']
    document.getElementById('pz').style.backgroundRepeat= tema['r']
    document.getElementById('pz').style.backgroundSize = tema['pz']
    document.getElementById('vr').style.backgroundSize = tema['l']
    document.getElementById('vr').style.backgroundImage = tema['k']
    document.getElementById('clock').style.backgroundColor = tema['t']
    
    document.getElementById('clock3').style.backgroundColor = tema['c']
    document.getElementById('mp').style.backgroundColor = tema['n']
    document.getElementById('body').style.backgroundColor = tema['m']
    document.getElementById('p').style.backgroundImage = tema['z']
    document.getElementById('body').style.backgroundSize = tema['q']
    document.getElementById('body').style.backgroundPosition = tema['m2']
    document.getElementById('p').style.backgroundSize = tema['o']
    document.getElementById('vr').style.backgroundColor = tema['p']
     document.getElementById('p').style.backgroundColor = tema['op']
     document.getElementById('uvedd').style.backgroundColor = tema['kj']
    }
    	 if(localStorage.getItem('bo')) {
                  tma = JSON.parse(localStorage.getItem('bo')  );
                  document.getElementById('body').style.backgroundImage = tma['h']
                      document.getElementById('obst').style.opacity = user['ob4']
    document.getElementById('obbl').style.opacity = user['ob2']
    document.getElementById('obst2').style.opacity = user['ob3']
    document.getElementById('obvista').style.opacity = user['ob1']
         }

/*
else {
    document.getElementById("vets").style.display = "block";
}
*/
    
}, 3000 );

//});
});

		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd5").addEventListener("click", function() {
				document.getElementById('calc').style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
            document.getElementById("vspr").style.display = 'none';
            document.getElementById("mp").style.display = 'none';
                        document.getElementById("pk5").style.display = 'none';
document.getElementById("otkrcalc").style.display = 'block';
				
			});
		});
        
        

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v2').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
document.getElementById('vets3').style.display = "block";
document.getElementById('winwer').style.display="none";
document.getElementById('task').style.display="none";
document.getElementById('pass2').style.display="none";
document.getElementById("vi").style.display = 'none';
document.getElementById("vrema").style.display = 'none';
document.getElementById("pers2").style.display = 'none';
document.getElementById("kstr").style.display = 'none';
document.getElementById("paint").style.display = 'none';
window.setTimeout(function(){ document.getElementById('sp').style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets3").style.display = "none";

},5000);
document.getElementById('page').style.display = "none";
document.getElementById('mp').style.display = "none";
});
document.getElementById('vo').addEventListener('click', function() {
        nik = document.getElementById('ni').value;
    document.getElementById('u2').value = nik;
                
           
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";
});


});


		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
                        document.getElementById("otkrkstr").style.display = "block";

document.getElementById("pk2").style.display = "none";
				
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
                        document.getElementById("otkrkstr").style.display = "block";

document.getElementById("pk2").style.display = "none";
				
			});
		});
	
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("kstr2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "none";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
            
				            document.getElementById("otkrkstr").style.display = "none";

document.getElementById("pk2").style.display = "block";
			});
		});

		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk3").addEventListener("click", function() {

    document.getElementById('paint').style.display = "block";
         document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
            document.getElementById("otkrp").style.display = "block";

document.getElementById("pk3").style.display = "none";
    
});});
				


		



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk5").addEventListener("click", function() {
				document.getElementById("calc").style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
            document.getElementById("otkrcalc").style.display = "block";

document.getElementById("pk5").style.display = "none";
				
			});
		});
	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("calc2").addEventListener("click", function() {
				document.getElementById("calc").style.display = "none";
document.getElementById("otkrcalc").style.display = "none";

document.getElementById("pk5").style.display = "block";

				
			});
		});















		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				document.getElementById("otkrkstr").style.display = "block";
document.getElementById('vspr').style.display = "none";
document.getElementById('mp').style.display = "none";
document.getElementById("pk2").style.display = "none";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd3").addEventListener("click", function() {
								document.getElementById("paint").style.display = "block";
                     document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
				document.getElementById("otkrp").style.display = "block";
document.getElementById('vspr').style.display = "none";
document.getElementById('mp').style.display = "none";
document.getElementById("pk3").style.display = "none";
			});
		});
        
        
        
var f;
f = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('mp').style.display = "none";


document.getElementById('p').addEventListener('click', function() {
f++;
if(f > 2) {
f = 1;
}
if(f == 1) {
document.getElementById('mp').style.display = "block";

}
else if (f == 2) {
document.getElementById('mp').style.display = "none";
document.getElementById('vspr').style.display = "none";
document.getElementById('v').style.display = "block";
//v2
document.getElementById('v3').style.display = "block";
}
});});

var l;
l = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('clock').style.display = "none";


document.getElementById('vr').addEventListener('click', function() {
l++;
if(l > 2) {
l = 1;
}
if(l == 1) {
document.getElementById('clock').style.display = "block";
document.getElementById('uvedd').style.display = "none";
}
else if (l == 2) {
document.getElementById('clock').style.display = "none";
document.getElementById('uvedd').style.display = "none";
}
});});

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v').addEventListener('click', function() {
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.close();

},5000);
});});

document.addEventListener('DOMContentLoaded', function() {


document.getElementById('vo2').addEventListener('click', function() {
document.getElementById('cad').style.display="none";
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";
    
    
            document.getElementById('u2').value = "Ванюха";
            localStorage.setItem('user', document.getElementById('u2').value);
    },5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";

});


});
/*
images = [
];
function Update(){
   javascript:window.close();
   }
function showImage(n) {
	document.getElementById('curtain').style.display = 'block';
	document.getElementById('imagel').style.display = 'block';
	document.getElementById('imagel').style.backgroundImage = 'url('+images[n]+')';

}
document.addEventListener('DOMContentLoaded' , function() {
	//alert();
	for(i = 0; i < images.length; i++)
	document.getElementById('page').innerHTML += '<div class="img" style="background-image:url('+images[i]+')" onclick="showImage('+1+');"></div>';
//showImage(6);

document.getElementById('button').addEventListener('click',function() {
document.getElementById('curtain').style.display = 'none';

document.getElementById('imagel').style.display = 'none';
});
});
*/
document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v3').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.location.href = "glav.html";

},5000);
});});
document.addEventListener('DOMContentLoaded', function() {

document.getElementById('zr2').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.location.href = "glav.html";

},5000);
});
document.getElementById('zr3').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";

window.setTimeout(function(){ 

window.close();

},5000);
});
document.getElementById('zr4').addEventListener('click', function() {
document.getElementById('vets3').style.display = "block";
document.getElementById('winwer').style.display="none";
document.getElementById('task').style.display="none";
document.getElementById('pass2').style.display="none";
document.getElementById('cad').style.display="none";
document.getElementById("vi").style.display = 'none';
document.getElementById("vrema").style.display = 'none';
document.getElementById("pers2").style.display = 'none';
document.getElementById("kstr").style.display = 'none';
document.getElementById("paint").style.display = 'none';
window.setTimeout(function(){ document.getElementById('sp').style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets3").style.display = "none";

},5000);
document.getElementById('page').style.display = "none";
document.getElementById('mp').style.display = "none";



});});


