

        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("cam2").addEventListener("click", function() {

				document.getElementById("cam").style.display = 'none';
			});
		});


                /*
                
                        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("passakt").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'block';
         
			});
		});   */  	document.addEventListener("DOMContentLoaded", function() {
                                
                /*                
                            	
			document.getElementById("passz").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'none';
         
			});*/
            
            
            
            			document.getElementById("parol").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
                                    document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
         
			});
    
            
            
            			document.getElementById("pyuse").addEventListener("click", function() {
                            p = document.getElementById("newpass").value;
                               p = localStorage.getItem('passw');
				localStorage.setItem('passw', p);
             
         
			});
            
            
                        
                 			document.getElementById("cl1").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'red';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});       
                        
                               			document.getElementById("cl2").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'gold';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                               			document.getElementById("cl3").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'white';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                                               			document.getElementById("cl4").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'lightblue';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                        
                                                                              			document.getElementById("cl5").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'black';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});          
                        
            
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                    			document.getElementById("pk11").addEventListener("click", function() {
				document.getElementById("str").style.display = 'block';
                document.getElementById("pk11").style.display = 'none';
                 document.getElementById("otkrstr").style.display = "block";
                                    document.getElementById('str').style.position = "fixed";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";
         
			});                                                                                
                                                                                        
                  			document.getElementById("str2").addEventListener("click", function() {
                                 document.getElementById("otkrstr").style.display = "none";
document.getElementById("pk11").style.display = 'block';
				document.getElementById("str").style.display = 'none';

			});                                                                      
                        			document.getElementById("player2").addEventListener("click", function() {

				document.getElementById("player").style.display = 'none';

			});      
                            
                  			document.getElementById("pkd13").addEventListener("click", function() {

document.getElementById("cam").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
			});  
                            
                            
                            
                          
                    			document.getElementById("pkd15").addEventListener("click", function() {
				document.getElementById("player").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('player').style.position = "fixed";
            document.getElementById('player').style.left = "0";
            document.getElementById('player').style.top = "0";
         
			});  
                          
            
                                
                                
                                
                                
document.getElementById("fg").addEventListener("click", function() {
localStorage.removeItem('bo');
localStorage.removeItem('gad');
localStorage.removeItem('passw');
localStorage.removeItem('us');
localStorage.removeItem('col');
localStorage.removeItem('tem');
localStorage.removeItem('user');
localStorage.removeItem('par');
localStorage.removeItem('volume');
			});  
                         
                                
        });   
