var f;
f = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('vspr').style.display = "none";


document.getElementById('vsp').addEventListener('click', function() {
f++;
if(f > 2) {
f = 1;
}
if(f == 1) {
document.getElementById('vspr').style.display = "none";
document.getElementById('vsp').style.backgroundColor = "darkblue";
document.getElementById('v').style.display = "block";
//v2
document.getElementById('v3').style.display = "block";
}
else if (f == 2) {
document.getElementById('vspr').style.display = "block";

document.getElementById('vsp').style.backgroundColor = "blue";
}
});});
