		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("user").addEventListener("click", function() {
				
				document.getElementById('pyuse').style.display = "block";
                     document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
			});
		});
document.addEventListener('DOMContentLoaded', function() {
/*document.getElementById('bootm').style.display = "block";
document.getElementById('page').style.display = "none";
document.getElementById('vets4').style.display = "none";
document.getElementById("bootb").addEventListener("click", function() {
document.getElementById('bootm').style.display = "none";
*/
    document.getElementById('page').style.display = "none";
 document.getElementById('vets4').style.display = "block";
window.setTimeout(function(){ 
document.getElementById("vets4").style.display = "block";
document.getElementById("vets").style.display = "none";

},10000);
window.setTimeout(function(){ 
document.getElementById("vets4").style.display = "none";
document.getElementById("vets").style.display = "block";

},20000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";


document.getElementById('page').style.display = "block";
},25000);

//});
});


		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd5").addEventListener("click", function() {
				document.getElementById('calc').style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
				
			});
		});
        
        

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v2').addEventListener('click', function() {
document.getElementById('vets3').style.display = "block";
window.setTimeout(function(){ document.getElementById('sp').style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets3").style.display = "none";

},5000);
document.getElementById('page').style.display = "none";
document.getElementById('mp').style.display = "none";
});
document.getElementById('vo').addEventListener('click', function() {
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";
});


});


		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				
			});
		});
	
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("kstr2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "none";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				
			});
		});

		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk3").addEventListener("click", function() {

    document.getElementById('paint').style.display = "block";
         document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
    
});});
				


		



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk5").addEventListener("click", function() {
				document.getElementById("calc").style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
				
			});
		});
	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("calc2").addEventListener("click", function() {
				document.getElementById("calc").style.display = "none";
				
			});
		});















		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd3").addEventListener("click", function() {
				win = window.open("system32/pr/paint.html", "Вход в систему", "menubar=no,location=no,resizable=no,scrollbars=yes,status=no,width=600,height=700");
				
			});
		});
        
        
        
var f;
f = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('mp').style.display = "none";


document.getElementById('p').addEventListener('click', function() {
f++;
if(f > 2) {
f = 1;
}
if(f == 1) {
document.getElementById('mp').style.display = "block";

}
else if (f == 2) {
document.getElementById('mp').style.display = "none";

}
});});

var l;
l = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('clock').style.display = "none";


document.getElementById('vr').addEventListener('click', function() {
l++;
if(l > 2) {
l = 1;
}
if(l == 1) {
document.getElementById('clock').style.display = "block";
}
else if (l == 2) {
document.getElementById('clock').style.display = "none";
}
});});

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v').addEventListener('click', function() {
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.close();

},5000);
});});

document.addEventListener('DOMContentLoaded', function() {


document.getElementById('vo2').addEventListener('click', function() {
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";
});


});

