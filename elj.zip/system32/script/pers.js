 
 
 		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("redp").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "red";

			});
		});
 
 
 
 
  mouseX = 0;
      mouseY = 0;
      shiftX = 0;
      shiftY = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);
        mouseX = e.clientX;
        mouseY = e.clientY;
      });
      
      blockHold = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('pers2').addEventListener('mousedown', function(e) {
          blockHold = true;
          x = parseInt(document.getElementById('pers2').style.left);
          y = parseInt(document.getElementById('pers2').style.top);
          shiftX = e.clientX - x;
          shiftY = e.clientY - y;
        });
        anim();
      });
      
      document.addEventListener('mouseup', function() { blockHold = false });
      

      function anim() {
        
        if(blockHold) {
          document.getElementById('pers2').style.left = (mouseX-shiftX) + 'px';
          document.getElementById('pers2').style.top = (mouseY-shiftY) + 'px';
        }
        
        window.setTimeout(function() { anim() }, 40);
      }



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("red").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundColor = "red";
				document.getElementById('clock').style.backgroundColor = "red";
				document.getElementById('vr').style.backgroundColor = "red";
				document.getElementById('clock3').style.backgroundColor = "red";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("blue").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundImage = "url(img/st.png)";
				document.getElementById('clock').style.backgroundColor = "blue";
                 document.getElementById('pz').style.backgroundColor = "none";
                    document.getElementById('vr').style.backgroundImage = "url(img/st.png)";
                     document.getElementById('vr').style.backgroundColor = "none";
                      document.getElementById('vr').style.backgroundSize = "contain";
				document.getElementById('clock3').style.backgroundColor = "blue";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("yellow").addEventListener("click", function() {
				document.getElementById('pz').style.backgroundColor = "yellow";
				document.getElementById('clock').style.backgroundColor = "yellow";
				document.getElementById('vr').style.backgroundColor = "yellow";
				document.getElementById('clock3').style.backgroundColor = "yellow";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("redt").addEventListener("click", function() {
				document.getElementById('clock').style.backgroundColor = "#e0e0e096";
				document.getElementById('vr').style.backgroundColor = "#e0e0e00";
				document.getElementById('clock3').style.backgroundColor = "#e0e0e00";
				document.getElementById('mp').style.backgroundColor = "#e0e0e096";
				document.getElementById('body').style.backgroundColor = "none";
                document.getElementById('clock3').style.backgroundImage = "none";
                document.getElementById('clock').style.backgroundImage = "none";
                document.getElementById('clock2').style.backgroundImage = "none";
				document.getElementById('p').style.backgroundColor = "darkgray";
				document.getElementById('body').style.backgroundImage = "url(system32/css/img/vista.jpg)";
				     document.getElementById('p').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundColor = "#e0e0e096";
                document.getElementById('vr').style.backgroundImage = "none";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("bluet").addEventListener("click", function() {
				
				document.getElementById('clock').style.backgroundImage = "url(system32/css/img/st.png)";
				document.getElementById('vr').style.backgroundImage = "url(system32/css/img/st.png)";
                document.getElementById('vr').style.backgroundSize = "cover";
         
				document.getElementById('clock3').style.backgroundImage = "none";
                document.getElementById('clock').style.backgroundSize = "cover";
				document.getElementById('mp').style.backgroundColor = "lightblue";
				document.getElementById('body').style.backgroundColor = "none";
                document.getElementById('body').style.backgroundImage = "url(system32/css/img/body.jpg)";
				document.getElementById('p').style.backgroundColor = "green";
                document.getElementById('p').style.backgroundImage = "none";
                document.getElementById('pz').style.backgroundImage = "url(system32/css/img/st.png)";
                document.getElementById('pz').style.backgroundColor = "none";
                document.getElementById('vr').style.backgroundColor = "none";
			});
		});

		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("stt").addEventListener("click", function() {
                document.getElementById('pz').style.backgroundColor = "none";
				document.getElementById('pz').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('pz').style.backgroundRepeat = "repeat-x";
                document.getElementById('pz').style.backgroundSize = "contain";
				document.getElementById('vr').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('vr').style.backgroundSize = "contain";
				document.getElementById('clock').style.backgroundColor = "black";
				document.getElementById('clock3').style.backgroundColor = "black";
				document.getElementById('mp').style.backgroundColor = "black";
                document.getElementById('mp').style.Opacity = "0.5";
				document.getElementById('body').style.backgroundColor = "none";
				document.getElementById('p').style.backgroundImage = "url(system32/css/img/logo.png)";
                document.getElementById('body').style.backgroundImage = "url(system32/css/img/vista.jpg)";
                document.getElementById('body').style.backgroundSize = "cover";
                document.getElementById('body').style.backgroundPosition = "center";
                document.getElementById('p').style.backgroundSize = "contain";
        
			});
		});
		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("bluep").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "lightblue";

			});
		});



		




		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("yellowp").addEventListener("click", function() {

				document.getElementById('mp').style.backgroundColor = "yellow";

			});
		});
		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pers3").addEventListener("click", function() {
				document.getElementById('pers2').style.display = "none";
				
			});
		});
        
        
        
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd7").addEventListener("click", function() {
				document.getElementById('pers2').style.display = "block";
				     document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
			});
		});
                
                
        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk7").addEventListener("click", function() {
               
			document.getElementById('pers2').style.display = "block";
             document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
				
			});
		});
                
                
   mouseX3 = 0;
      mouseY3 = 0;
      shiftX3 = 0;
      shiftY3 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX3 = e.clientX;
        mouseY3 = e.clientY;
      });
      
      bloc = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('kstr').addEventListener('mousedown', function(e) {
          bloc = true;
          x = parseInt(document.getElementById('kstr').style.left);
          y = parseInt(document.getElementById('kstr').style.top);
          shiftX3 = e.clientX - x;
          shiftY3 = e.clientY - y;
        });
        anim4();
      });
      
      document.addEventListener('mouseup', function() { bloc = false });
      
   
      function anim4() {
        
        if(bloc) {
          document.getElementById('kstr').style.left = (mouseX3-shiftX3) + 'px';
          document.getElementById('kstr').style.top = (mouseY3-shiftY3) + 'px';
        }
        
        window.setTimeout(function() { anim4() }, 40);
      }
