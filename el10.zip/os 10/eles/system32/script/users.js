function login() {
    
    document.getElementById("passw").style.display = "none";
        document.getElementById("passwb").style.display = "none";
        
            	 if(localStorage.getItem('bo2')) {
                  teema = JSON.parse(localStorage.getItem('bo2')  );
                  document.getElementById('vets').style.backgroundImage = teema['h2']
document.getElementById('vets2').style.backgroundImage = teema['h3']
document.getElementById('vets3').style.backgroundImage = teema['h4']
         }
         
    window.setTimeout(function(){ 
    document.getElementById('u2').style.color = localStorage.getItem('col');
    document.getElementById("pyuse").style.display = 'none';
        document.getElementById("parol").style.display = 'none';
            localStorage.setItem('par', document.getElementById('parol').style.display);




document.getElementById("vets").style.display = "none";


document.getElementById('page').style.display = "block";
	document.getElementById('u2').value = localStorage.getItem('user');
document.getElementById('user').setAttribute('data-title', document.getElementById('u2').value)
    	document.getElementById('gadj').style.display = localStorage.getItem('gad');

     
     
    if(localStorage.getItem('tem')) {
     tema = JSON.parse(localStorage.getItem('tem')  );

    document.getElementById('pz').style.backgroundColor = tema['bg']
    document.getElementById('pz').style.backgroundImage = tema['img']
    document.getElementById('pz').style.backgroundRepeat= tema['r']
    document.getElementById('pz').style.backgroundSize = tema['pz']
    document.getElementById('vr').style.backgroundSize = tema['l']
    document.getElementById('vr').style.backgroundImage = tema['k']
    document.getElementById('clock').style.backgroundColor = tema['t']

    document.getElementById('mp').style.backgroundColor = tema['n']
    for(i=0; i<document.getElementsByClassName('pol3').length; i++) {
    document.getElementsByClassName('pol3')[i].style.backgroundColor = tema['lll']
    }
    for(i2=0; i2<document.getElementsByClassName('pkddd1').length; i2++) {
document.getElementsByClassName('pkddd1')[i2].style.color = tema['llll'];
                }
    document.getElementById('body').style.backgroundColor = tema['m']
    document.getElementById('p').style.backgroundImage = tema['z']

    document.getElementById('p').style.backgroundSize = tema['o']

     document.getElementById('p').style.backgroundColor = tema['op']
     document.getElementById('uvedd').style.backgroundColor = tema['kj']
    }
    	 if(localStorage.getItem('bo')) {
                  tma = JSON.parse(localStorage.getItem('bo')  );
                  document.getElementById('body').style.backgroundImage = tma['h']
                      document.getElementById('obst').style.opacity = tma['ob4']
    document.getElementById('obos').style.opacity = tma['ob6']
    document.getElementById('obos2').style.opacity = tma['ob5']
    document.getElementById('obbl').style.opacity = tma['ob2']
    document.getElementById('obst2').style.opacity = tma['ob3']
    document.getElementById('obvista').style.opacity = tma['ob1']
         }
         


    },2000);
   
}



	document.addEventListener('DOMContentLoaded', function() {
        
        
        
        
        
        
        
var p

document.getElementById('newpassb').addEventListener('click', function() {

p = document.getElementById("newpass").value;
localStorage.setItem('passw', p);
});

var nik;



document.getElementById('nib').addEventListener('click', function() {
    nik = document.getElementById('ni').value;

    document.getElementById('u2').value =  nik;
    
    localStorage.setItem('user', document.getElementById('u2').value);

});
});
	
	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("user").addEventListener("click", function() {
				
				document.getElementById('pyuse').style.display = "block";
                     document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";

document.getElementById("otkruser").style.display = 'block';
			});
		});
document.addEventListener('DOMContentLoaded', function() {
/*document.getElementById('bootm').style.display = "block";
document.getElementById('page').style.display = "none";
document.getElementById('vets4').style.display = "none";
document.getElementById("bootb").addEventListener("click", function() {
document.getElementById('bootm').style.display = "none";
*/

    document.getElementById('page').style.display = "none";
 document.getElementById('vets4').style.display = "block";
window.setTimeout(function(){ 
document.getElementById("vets4").style.display = "block";
document.getElementById("vets").style.display = "none";
     if(localStorage.getItem('us')) {
     user = JSON.parse(localStorage.getItem('us')  );
       document.getElementById('userpic').style.backgroundImage = user['ur']
       document.getElementById('logo').style.backgroundImage = user['l']
    document.getElementById('usp2').style.opacity = user['usp2']
    document.getElementById('usp3').style.opacity = user['usp3']
    document.getElementById('usp4').style.opacity = user['usp4']
    document.getElementById('usp5').style.opacity = user['usp5']
    document.getElementById('usp6').style.opacity = user['usp6']
    document.getElementById('usp').style.opacity = user['usp']
     }
     
             	 if(localStorage.getItem('volume')) {
                  vol = JSON.parse(localStorage.getItem('volume')  );
                  document.getElementById('audio').volume = vol['a1']
                  document.getElementById('audio2').volume = vol['a2']
                  document.getElementById('audio3').volume = vol['a3']
                  document.getElementById('audio4').volume = vol['a4']
                  document.getElementById('audio5').volume = vol['a5']
         }
     
},2000);
window.setTimeout(function(){ 
            	 if(localStorage.getItem('bo2')) {
                  teema = JSON.parse(localStorage.getItem('bo2')  );
                  document.getElementById('vets').style.backgroundImage = teema['h2']
document.getElementById('vets2').style.backgroundImage = teema['h3']
document.getElementById('vets3').style.backgroundImage = teema['h4']
         }
            if(localStorage.getItem('oil') == null) {
                document.getElementById('usp6').style.display = "none";
            }
            else {
                document.getElementById('usp6').style.display = "block";
            }

document.getElementById("vets4").style.display = "none";
p = localStorage.getItem('passw');
document.getElementById("vets").style.display = "block";
        	document.getElementById('parol').style.display = localStorage.getItem('par');
if(p == '') {
    login();
}
},4000);




document.getElementById('passwb').addEventListener('click', function() {

if(document.getElementById('passw').value == p) {
          document.getElementById('audio4').play();
login();
}
/*
else {
    document.getElementById("vets").style.display = "block";
}
*/
    



});

//});
});



		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd5").addEventListener("click", function() {
				document.getElementById('calc').style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
            document.getElementById("vspr").style.display = 'none';
            document.getElementById("mp").style.display = 'none';
                        document.getElementById("pk5").style.display = 'none';
document.getElementById("otkrcalc").style.display = 'block';
				
			});
		});
        
        

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v2').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
document.getElementById('vets3').style.display = "block";
document.getElementById('winwer').style.display="none";
document.getElementById('task').style.display="none";
document.getElementById('pass2').style.display="none";
document.getElementById("vi").style.display = 'none';
document.getElementById("vrema").style.display = 'none';
document.getElementById("pers2").style.display = 'none';
document.getElementById("kstr").style.display = 'none';
document.getElementById("paint").style.display = 'none';
window.setTimeout(function(){ document.getElementById('sp').style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets3").style.display = "none";

},5000);
document.getElementById('page').style.display = "none";
document.getElementById('mp').style.display = "none";
});
document.getElementById('vo').addEventListener('click', function() {
        nik = document.getElementById('ni').value;
    document.getElementById('u2').value = nik;
                
           
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";},5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";
});


});


		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
                        document.getElementById("otkrkstr").style.display = "block";

document.getElementById("pk2").style.display = "none";
				
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
                        document.getElementById("otkrkstr").style.display = "block";

document.getElementById("pk2").style.display = "none";
				
			});
		});
	
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("kstr2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "none";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
            
				            document.getElementById("otkrkstr").style.display = "none";

document.getElementById("pk2").style.display = "block";
			});
		});

		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk3").addEventListener("click", function() {

    document.getElementById('paint').style.display = "block";
         document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
            document.getElementById("otkrp").style.display = "block";

document.getElementById("pk3").style.display = "none";
    
});});
				


		



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pk5").addEventListener("click", function() {
				document.getElementById("calc").style.display = "block";
                     document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
            document.getElementById("otkrcalc").style.display = "block";

document.getElementById("pk5").style.display = "none";
				
			});
            
            
            		document.getElementById("pkd12").addEventListener("click", function() {
				document.getElementById("str").style.display = "block";
                document.getElementById("otkrstr").style.display = "block";
                     document.getElementById('str').style.Position = "fixed";
                     document.getElementById("vspr").style.display = "none";
                     document.getElementById("mp").style.display = "none";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";

document.getElementById("pk11").style.display = "none";
				
			});
            
            
            
		});
	document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("calc2").addEventListener("click", function() {
				document.getElementById("calc").style.display = "none";
document.getElementById("otkrcalc").style.display = "none";

document.getElementById("pk5").style.display = "block";

				
			});
		});















		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = "block";
                     document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById('kstr').style.top = "0";
				document.getElementById("otkrkstr").style.display = "block";
document.getElementById('vspr').style.display = "none";
document.getElementById('mp').style.display = "none";
document.getElementById("pk2").style.display = "none";
			});
		});



		
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pkd3").addEventListener("click", function() {
								document.getElementById("paint").style.display = "block";
                     document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
				document.getElementById("otkrp").style.display = "block";
document.getElementById('vspr').style.display = "none";
document.getElementById('mp').style.display = "none";
document.getElementById("pk3").style.display = "none";
			});
		});
        
        
        var fff;
fff = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('menubr').style.display = "none";


document.getElementById('menubrb').addEventListener('click', function() {
fff++;
if(fff > 2) {
fff = 1;
}
if(fff == 1) {
document.getElementById('menubr').style.display = "block";

}
else if (fff == 2) {
document.getElementById('menubr').style.display = "none";
//v2
}
});});



var f;
f = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('mp').style.display = "none";


document.getElementById('p').addEventListener('click', function() {
f++;
if(f > 2) {
f = 1;
}
if(f == 1) {
document.getElementById('mp').style.display = "block";

}
else if (f == 2) {
document.getElementById('mp').style.display = "none";
document.getElementById('vspr').style.display = "none";
document.getElementById('v').style.display = "block";
//v2
document.getElementById('v3').style.display = "block";
}
});});

var l;
l = 0;

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('clock').style.display = "none";


document.getElementById('vr').addEventListener('click', function() {
l++;
if(l > 2) {
l = 1;
}
if(l == 1) {
document.getElementById('clock').style.display = "block";

}
else if (l == 2) {
document.getElementById('clock').style.display = "none";

}
});});


// var l2;
// l2 = 0;
// 
// document.addEventListener('DOMContentLoaded', function() {
// document.getElementById('zag2').style.display = "none";
// 
// 
// document.getElementById('zag').addEventListener('click', function() {
// l2++;
// if(l2 > 2) {
// l2 = 1;
// }
// if(l2 == 1) {
//     document.getElementById('zag2').style.display = "block";
//       window.setTimeout(function() {
//           document.getElementById('zag2').style.display = "none";
//       }, 1000);
//      window.setTimeout(function() {
//         document.getElementById('bsod').style.display = 'block';
//         document.getElementById('page').style.display = 'none';
//                                document.getElementById('str').style.dislay = "none";
//      }, 2000);
//                         window.setTimeout(function() {
//                         
//                         window.location.href="glav.html";
//                         }, 4000);
// 
// 
// }
// else if (l2 == 2) {
// 
// 
// }
// });});

document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v').addEventListener('click', function() {
            document.getElementById('pyuse').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.close();

},5000);
});});

document.addEventListener('DOMContentLoaded', function() {


document.getElementById('vo2').addEventListener('click', function() {
document.getElementById('cad').style.display="none";
document.getElementById('vets').style.display = "block";
window.setTimeout(function(){ document.getElementById("page").style.display = "block";
    
    
            document.getElementById('u2').value = "Ванюха";
            localStorage.setItem('user', document.getElementById('u2').value);
    },5000);
window.setTimeout(function(){ 

document.getElementById("vets").style.display = "none";

},5000);
document.getElementById('sp').style.display = "none";

});


});
/*
images = [
];
function Update(){
   javascript:window.close();
   }
function showImage(n) {
	document.getElementById('curtain').style.display = 'block';
	document.getElementById('imagel').style.display = 'block';
	document.getElementById('imagel').style.backgroundImage = 'url('+images[n]+')';

}
document.addEventListener('DOMContentLoaded' , function() {
	//alert();
	for(i = 0; i < images.length; i++)
	document.getElementById('page').innerHTML += '<div class="img" style="background-image:url('+images[i]+')" onclick="showImage('+1+');"></div>';
//showImage(6);

document.getElementById('button').addEventListener('click',function() {
document.getElementById('curtain').style.display = 'none';

document.getElementById('imagel').style.display = 'none';
});
});
*/
document.addEventListener('DOMContentLoaded', function() {

document.getElementById('v3').addEventListener('click', function() {
    document.getElementById('cad').style.display="none";
        document.getElementById('pyuse').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.location.href = "glav.html";

},5000);
});});
document.addEventListener('DOMContentLoaded', function() {

document.getElementById('zr2').addEventListener('click', function() {
    document.getElementById('audio2').play();
    document.getElementById('cad').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";
window.setTimeout(function(){ 

window.location.href = "glav.html";

},5000);
});
document.getElementById('zr3').addEventListener('click', function() {
    document.getElementById('audio2').play();
    document.getElementById('cad').style.display="none";
document.getElementById('page').style.display = "none";
document.getElementById('vets2').style.display = "block";

window.setTimeout(function(){ 

window.close();

},5000);
});
});

//                document.addEventListener('DOMContentLoaded', function() {             
//                     			document.getElementById("psv").addEventListener("click", function() {
// 
// 				document.getElementById("stnv").style.display = 'none';
// document.getElementById("nv").style.display = 'block';
// 			});
//                                 			document.getElementById("pnv").addEventListener("click", function() {
// 
// 				document.getElementById("nv").style.display = 'none';
// document.getElementById("stnv").style.display = 'block';
// 			});
//                });
//                
//                




