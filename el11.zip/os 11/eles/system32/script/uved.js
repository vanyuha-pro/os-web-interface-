

        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("cam2").addEventListener("click", function() {

				document.getElementById("cam").style.display = 'none';
			});
		});


                /*
                
                        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("passakt").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'block';
         
			});
		});   */  	document.addEventListener("DOMContentLoaded", function() {
                                
                /*                
                            	
			document.getElementById("passz").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'none';
         
			});*/
            
            
            
            			document.getElementById("parol").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
                                    document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
         
			});
    
            
            
            			document.getElementById("pyuse").addEventListener("click", function() {
                            p = document.getElementById("newpass").value;
                               p = localStorage.getItem('passw');
				localStorage.setItem('passw', p);
             
         
			});
            
            
                        
                 			document.getElementById("cl1").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'red';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});       
                        
                               			document.getElementById("cl2").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'gold';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                               			document.getElementById("cl3").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'white';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                                               			document.getElementById("cl4").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'lightblue';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                        
                                                                              			document.getElementById("cl5").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'black';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});          
                        
            
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                    			document.getElementById("pk11").addEventListener("click", function() {
				document.getElementById("str").style.display = 'block';
                document.getElementById("pk11").style.display = 'none';
                 document.getElementById("otkrstr").style.display = "block";
                                    document.getElementById('str').style.position = "fixed";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";
         
			});                                                                                
                                                                                        
                  			document.getElementById("str2").addEventListener("click", function() {
                                 document.getElementById("otkrstr").style.display = "none";
document.getElementById("pk11").style.display = 'block';
				document.getElementById("str").style.display = 'none';

			});                                                                      
                        			document.getElementById("player2").addEventListener("click", function() {

				document.getElementById("player").style.display = 'none';

			});      
                            
                  			document.getElementById("pkd13").addEventListener("click", function() {

document.getElementById("cam").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
			});  
                            
                            
                            
                          
                    			document.getElementById("pkd15").addEventListener("click", function() {
				document.getElementById("player").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('player').style.position = "fixed";
            document.getElementById('player').style.left = "0";
            document.getElementById('player').style.top = "0";
         
			});  
                          
            
                                
                                        
            			document.getElementById("pkdd2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = 'block';
                                    document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById("poi").style.display = 'none';
            document.getElementById('kstr').style.top = "0";
                        document.getElementById('otkrkstr').style.display = "block";
            document.getElementById('pk2').style.display = "none";
         
			});    
                   
                         			document.getElementById("pkdd3").addEventListener("click", function() {
				document.getElementById("paint").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
                        document.getElementById('otkrp').style.display = "block";
            document.getElementById('pk3').style.display = "none";
         
			});    
                                    
           
                         			document.getElementById("pkdd4").addEventListener("click", function() {
				document.getElementById("prog").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('prog').style.Position = "fixed";
            document.getElementById('prog').style.left = "0";
            document.getElementById('prog').style.top = "0";
                     document.getElementById('otkrpk').style.display = "block";
            document.getElementById('pk9').style.display = "none";
			});    

                         			document.getElementById("pkdd5").addEventListener("click", function() {
				document.getElementById("calc").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
                        document.getElementById('otkrcalc').style.display = "block";
            document.getElementById('pk5').style.display = "none";
         
			});    
                                    
                         			document.getElementById("pkdd6").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
         
			});    
                                    
                                    
                                    
                         			document.getElementById("pkdd7").addEventListener("click", function() {
				document.getElementById("pers2").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
                        document.getElementById('otkrpers').style.display = "block";
            document.getElementById('pk7').style.display = "none";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd8").addEventListener("click", function() {
				document.getElementById("vrema").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('vrema').style.Position = "fixed";
            document.getElementById('vrema').style.left = "0";
            document.getElementById('vrema').style.top = "0";

         
			});    
                                    
                         			document.getElementById("pkdd9").addEventListener("click", function() {
				document.getElementById("block").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('block').style.Position = "fixed";
            document.getElementById('block').style.left = "0";
            document.getElementById('block').style.top = "0";
                                 document.getElementById('otkrb').style.display = "block";
            document.getElementById('pk8').style.display = "none";
			});    
                                    
                                    
                         			document.getElementById("pkdd10").addEventListener("click", function() {
				document.getElementById("task").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('taskmgr').style.Position = "fixed";
            document.getElementById('task').style.left = "0";
            document.getElementById('task').style.top = "0";
         
			});    
                                    
                         			document.getElementById("pkdd11").addEventListener("click", function() {
				document.getElementById("pass2").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('pass2').style.Position = "fixed";
            document.getElementById('pass2').style.left = "0";
            document.getElementById('pass2').style.top = "0";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd12").addEventListener("click", function() {
				document.getElementById("str").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('str').style.Position = "fixed";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";
                                    document.getElementById('otkrstr').style.display = "block";
            document.getElementById('pk10').style.display = "none";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd13").addEventListener("click", function() {
				document.getElementById("cam").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('cam').style.Position = "fixed";
            document.getElementById('cam').style.left = "0";
            document.getElementById('cam').style.top = "0";
         
			});    
                                    
                                    
                                    
                         			document.getElementById("pkdd15").addEventListener("click", function() {
				document.getElementById("player").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('player').style.Position = "fixed";
            document.getElementById('player').style.left = "0";
            document.getElementById('player').style.top = "0";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd16").addEventListener("click", function() {
				document.getElementById("winwer").style.display = 'block';
                document.getElementById("poi").style.display = 'none';
                                    document.getElementById('winwer').style.Position = "fixed";
            document.getElementById('winwer').style.left = "0";
            document.getElementById('winwer').style.top = "0";
         
			});    
document.getElementById("fg").addEventListener("click", function() {
localStorage.removeItem('bo');
localStorage.removeItem('bo2');
localStorage.removeItem('gad');
localStorage.removeItem('passw');
localStorage.removeItem('us');
localStorage.removeItem('col');
localStorage.removeItem('tem');
localStorage.removeItem('user');
localStorage.removeItem('par');
localStorage.removeItem('volume');
			});  
                         
                                


        
        
        

        
                         			document.getElementById("pkddd1").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
         
			});    
                                    
                         			document.getElementById("pkddd2").addEventListener("click", function() {
				document.getElementById("pers2").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('pers2').style.Position = "fixed";
            document.getElementById('pers2').style.left = "0";
            document.getElementById('pers2').style.top = "0";
         
			});    
                                    
                                    
                         			document.getElementById("pkddd3").addEventListener("click", function() {
				document.getElementById("pass2").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('pass2').style.Position = "fixed";
            document.getElementById('pass2').style.left = "0";
            document.getElementById('pass2').style.top = "0";
         
			});    

                         			document.getElementById("pkddd4").addEventListener("click", function() {
                        window.location.href = "system32/block/pod.html";
         
			});    

                         			document.getElementById("pkddd5").addEventListener("click", function() {
				document.getElementById("vi").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
         
			});       

					                  			document.getElementById("knpoisk").addEventListener("click", function() {
				document.getElementById("poi").style.display = 'block';
                document.getElementById("mp").style.display = 'none';

			});

					                  			document.getElementById("spravka").addEventListener("click", function() {
				document.getElementById("spravka2").style.display = 'block';


			});
					                  			document.getElementById("spravka3").addEventListener("click", function() {
				document.getElementById("spravka2").style.display = 'none';


			});
                                    
                                  			document.getElementById("v4").addEventListener("click", function() {
				document.getElementById("vets3").style.display = 'block';
				document.getElementById('audio3').play();
                document.getElementById("page").style.display = 'none';
         
			});                                 
				document.getElementById("vets3").addEventListener("click", function() {

				document.getElementById('audio4').play();
                document.getElementById("vets3").style.display = 'none';
				document.getElementById("vets").style.display = 'block';
				    window.setTimeout(function(){
   document.getElementById("vets").style.display = 'none';
				document.getElementById("page").style.display = 'block';
					},3000);
         
			});                         
                                    
                                    
                                            });   
