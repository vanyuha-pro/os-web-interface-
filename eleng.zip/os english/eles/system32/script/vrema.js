/*
		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("pyvr").addEventListener("click", function() {
document.getElementById('vrema').style.display = "block";
     document.getElementById('vrema').style.Position = "fixed";
            document.getElementById('vrema').style.left = "0";
            document.getElementById('vrema').style.top = "0";
                        document.getElementById("otkrpers").style.display = "block";

document.getElementById("pk7").style.display = "none";
				
			});
		});*/

        

		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("vrema2").addEventListener("click", function() {
document.getElementById('vrema').style.display = "none";
            document.getElementById("pk7").style.display = "block";

document.getElementById("otkrpers").style.display = "none";
				
			});
		});
  mouseX2 = 0;
      mouseY2 = 0;
      shiftX2 = 0;
      shiftY2 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX2 = e.clientX;
        mouseY2 = e.clientY;
      });
      
      blockold = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('vrema').addEventListener('mousedown', function(e) {
          blockold = true;
          x = parseInt(document.getElementById('vrema').style.left);
          y = parseInt(document.getElementById('vrema').style.top);
          shiftX2 = e.clientX - x;
          shiftY2 = e.clientY - y;
        });
        anim2();
      });
      
      document.addEventListener('mouseup', function() { blockold = false });
     
      
      function anim2() {
        
        if(blockold) {
          document.getElementById('vrema').style.left = (mouseX2-shiftX2) + 'px';
          document.getElementById('vrema').style.top = (mouseY2-shiftY2) + 'px';
        }
        
        window.setTimeout(function() { anim2() }, 40);
      }
      


    mouseX4 = 0;
      mouseY4 = 0;
      shiftX4 = 0;
      shiftY4 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX4 = e.clientX;
        mouseY4 = e.clientY;
      });
      
      block = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('calc').addEventListener('mousedown', function(e) {
          block = true;
          x = parseInt(document.getElementById('calc').style.left);
          y = parseInt(document.getElementById('calc').style.top);
          shiftX4 = e.clientX - x;
          shiftY4 = e.clientY - y;
        });
        anim3();
      });
      
      document.addEventListener('mouseup', function() { block = false });
      
     
      
      function anim3() {
        
        if(block) {
          document.getElementById('calc').style.left = (mouseX4-shiftX4) + 'px';
          document.getElementById('calc').style.top = (mouseY4-shiftY4) + 'px';
        }
        
        window.setTimeout(function() { anim3() }, 40);
      }

      
    mouseX5 = 0;
      mouseY5 = 0;
      shiftX5 = 0;
      shiftY5 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX5 = e.clientX;
        mouseY5 = e.clientY;
      });
      
      b = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('winwer').addEventListener('mousedown', function(e) {
          b = true;
          x = parseInt(document.getElementById('winwer').style.left);
          y = parseInt(document.getElementById('winwer').style.top);
          shiftX5 = e.clientX - x;
          shiftY5 = e.clientY - y;
        });
        anim5();
      });
      
      document.addEventListener('mouseup', function() { b = false });
      

      
      function anim5() {
        
        if(b) {
          document.getElementById('winwer').style.left = (mouseX5-shiftX5) + 'px';
          document.getElementById('winwer').style.top = (mouseY5-shiftY5) + 'px';
        }
        
        window.setTimeout(function() { anim5() }, 40);
      }     
      
      
document.addEventListener('DOMContentLoaded', function() {



document.getElementById('winwer2').addEventListener('click', function() {
    document.getElementById('winwer').style.display = "none";
                document.getElementById("otkrwin").style.display = "none";


    
});});
    document.addEventListener('DOMContentLoaded', function() {



document.getElementById('paint2').addEventListener('click', function() {
    document.getElementById('paint').style.display = "none";
                document.getElementById("pk3").style.display = 'block';
document.getElementById("otkrp").style.display = 'none';
    
    
});});
    
    

  /*  
    
        mouseX6 = 0;
      mouseY6 = 0;
      shiftX6 = 0;
      shiftY6 = 0;
      document.addEventListener('mousemove', function(e) {
        //console.log(e);

        mouseX6 = e.clientX;
        mouseY6 = e.clientY;
      });
      
      bi = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('paint').addEventListener('mousedown', function(e) {
          bi = true;
          x = parseInt(document.getElementById('paint').style.left);
          y = parseInt(document.getElementById('paint').style.top);
          shiftX6 = e.clientX - x;
          shiftY6 = e.clientY - y;
        });
        anim6();
      });
      
      document.addEventListener('mouseup', function() { bi = false });
      
      document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        document.getElementById('paint').style.left = e.clientX + 'px';
        document.getElementById('paint').style.top = e.clientY + 'px';
      });
      
      function anim6() {
        
        if(bi) {
          document.getElementById('paint').style.left = (mouseX6-shiftX6) + 'px';
          document.getElementById('paint').style.top = (mouseY6-shiftY6) + 'px';
        }
        
        window.setTimeout(function() { anim6() }, 40);
      } */
  
