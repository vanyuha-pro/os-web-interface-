

mouseX8 = 0;
      mouseY8 = 0;
      shiftX8 = 0;
      shiftY8 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX8 = e2.clientX;
        mouseY8 = e2.clientY;
      });
      
      o = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('pyuse').addEventListener('mousedown', function(e2) {
          o = true;
          x = parseInt(document.getElementById('pyuse').style.left);
          y = parseInt(document.getElementById('pyuse').style.top);
          shiftX8 = e2.clientX - x;
          shiftY8 = e2.clientY - y;
        });
        anim8();
      });
      
      document.addEventListener('mouseup', function() { o = false });
      

      
      function anim8() {
        
        if(o) {
          document.getElementById('pyuse').style.left = (mouseX8-shiftX8) + 'px';
          document.getElementById('pyuse').style.top = (mouseY8-shiftY8) + 'px';
        }
        
        window.setTimeout(function() { anim8() }, 40);
      }
mouseX9 = 0;
      mouseY9 = 0;
      shiftX9 = 0;
      shiftY9 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX9 = e2.clientX;
        mouseY9 = e2.clientY;
      });
      
      j = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('block').addEventListener('mousedown', function(e2) {
          j = true;
          x = parseInt(document.getElementById('block').style.left);
          y = parseInt(document.getElementById('block').style.top);
          shiftX9 = e2.clientX - x;
          shiftY9 = e2.clientY - y;
        });
        anim9();
      });
      
      document.addEventListener('mouseup', function() { j = false });
      

      
      function anim9() {
        
        if(j) {
          document.getElementById('block').style.left = (mouseX9-shiftX9) + 'px';
          document.getElementById('block').style.top = (mouseY9-shiftY9) + 'px';
        }
        
        window.setTimeout(function() { anim9() }, 40);
      }
