

        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("cam2").addEventListener("click", function() {

				document.getElementById("cam").style.display = 'none';
				document.getElementById("otkrcam").style.display = 'none';
			});
		});


                /*
                
                        		document.addEventListener("DOMContentLoaded", function() {
			document.getElementById("passakt").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'block';
         
			});
		});   */  	document.addEventListener("DOMContentLoaded", function() {
                                
                /*                
                            	
			document.getElementById("passz").addEventListener("click", function() {
				document.getElementById("passzad").style.display = 'none';
         
			});*/
            
            

    
            
            
            			document.getElementById("pyuse").addEventListener("click", function() {
                            p = document.getElementById("newpass").value;
                               p = localStorage.getItem('passw');
				localStorage.setItem('passw', p);
             
         
			});
            
            
                        
                 			document.getElementById("cl1").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'red';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});       
                        
                               			document.getElementById("cl2").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'gold';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                               			document.getElementById("cl3").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'white';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                                                               			document.getElementById("cl4").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'lightblue';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});    
                        
                                                                              			document.getElementById("cl5").addEventListener("click", function() {
				document.getElementById("u2").style.color = 'black';
                 localStorage.setItem('col', document.getElementById('u2').style.color);
         
			});          
                        
            
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                                                                                        
                    			document.getElementById("pk11").addEventListener("click", function() {
				document.getElementById("str").style.display = 'block';
                document.getElementById("pk11").style.display = 'none';
                 document.getElementById("otkrstr").style.display = "block";
                                    document.getElementById('str').style.position = "fixed";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";
         
			});                                                                                
                                                                                        
                  			document.getElementById("str2").addEventListener("click", function() {
                                 document.getElementById("otkrstr").style.display = "none";
				document.getElementById("str").style.display = 'none';

			});                                                                      
                        			document.getElementById("player2").addEventListener("click", function() {
document.getElementById('otkrplay').style.display = "none";
				document.getElementById("player").style.display = 'none';

			});      
                            
                  			document.getElementById("pkd13").addEventListener("click", function() {

document.getElementById("otkrcam").style.display = 'block';
document.getElementById("cam").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
			});  
                                     			document.getElementById("pkd17").addEventListener("click", function() {

document.getElementById("otkrmessage").style.display = 'block';
document.getElementById("telefon").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
			});
                            
                              			document.getElementById("pkd14").addEventListener("click", function() {

document.getElementById("otkrpod").style.display = 'block';
				document.getElementById("PodderDiv").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('PodderDiv').style.position = "fixed";
            document.getElementById('PodderDiv').style.left = "0";
            document.getElementById('PodderDiv').style.top = "0";

			});
                          
                    			document.getElementById("pkd15").addEventListener("click", function() {

document.getElementById("otkrplay").style.display = 'block';
				document.getElementById("player").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('player').style.position = "fixed";
            document.getElementById('player').style.left = "0";
            document.getElementById('player').style.top = "0";
         
			});  
                          
            
                              			document.getElementById("pkd16").addEventListener("click", function() {
				document.getElementById("regedit").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';

document.getElementById("otkrred").style.display = 'block';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('regedit').style.position = "fixed";
            document.getElementById('regedit').style.left = "0";
            document.getElementById('regedit').style.top = "0";

			});

                                               			document.getElementById("pkd18").addEventListener("click", function() {
				document.getElementById("bud").style.display = 'block';
				document.getElementById("vspr").style.display = 'none';

document.getElementById("otkrkalend").style.display = 'block';
				document.getElementById("mp").style.display = 'none';
                                    document.getElementById('bud').style.position = "fixed";
            document.getElementById('bud').style.left = "0";
            document.getElementById('bud').style.top = "0";

			});
            			document.getElementById("pkdd2").addEventListener("click", function() {
				document.getElementById("kstr").style.display = 'block';
                                    document.getElementById('kstr').style.Position = "fixed";
            document.getElementById('kstr').style.left = "0";
            document.getElementById("poi").style.left = '-620px';
            document.getElementById('kstr').style.top = "0";
                        document.getElementById('otkrkstr').style.display = "block";
            document.getElementById('pk2').style.display = "none";
         
			});    
                   
                         			document.getElementById("pkdd3").addEventListener("click", function() {
				document.getElementById("paint").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('paint').style.Position = "fixed";
            document.getElementById('paint').style.left = "0";
            document.getElementById('paint').style.top = "0";
                        document.getElementById('otkrp').style.display = "block";
            document.getElementById('pk3').style.display = "none";
         
			});    
                                    
           
                         			document.getElementById("pkdd4").addEventListener("click", function() {
				document.getElementById("prog").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('prog').style.Position = "fixed";
            document.getElementById('prog').style.left = "0";
            document.getElementById('prog').style.top = "0";
                     document.getElementById('otkrpk').style.display = "block";
            document.getElementById('pk9').style.display = "none";
			});    

                         			document.getElementById("pkdd5").addEventListener("click", function() {
				document.getElementById("calc").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('calc').style.Position = "fixed";
            document.getElementById('calc').style.left = "0";
            document.getElementById('calc').style.top = "0";
                        document.getElementById('otkrcalc').style.display = "block";
            document.getElementById('pk5').style.display = "none";
         
			});    
                                    
                         			document.getElementById("pkdd6").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('pyuse').style.Position = "fixed";
            document.getElementById('pyuse').style.left = "0";
            document.getElementById('pyuse').style.top = "0";
         
			});    
                                    
                                    
                                    
                         			document.getElementById("pkdd7").addEventListener("click", function() {
				document.getElementById("ControlPanel").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('ControlPanel').style.Position = "fixed";
            document.getElementById('ControlPanel').style.left = "0";
            document.getElementById('ControlPanel').style.top = "0";
                        document.getElementById('otkrpers').style.display = "block";
            document.getElementById('pk7').style.display = "none";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd8").addEventListener("click", function() {
				document.getElementById("vrema").style.display = 'block';
				document.getElementById("otkrkr-n").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('vrema').style.Position = "fixed";
            document.getElementById('vrema').style.left = "0";
            document.getElementById('vrema').style.top = "0";

         
			});    
                                    
                         			document.getElementById("pkdd9").addEventListener("click", function() {
				document.getElementById("block").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('block').style.Position = "fixed";
            document.getElementById('block').style.left = "0";
            document.getElementById('block').style.top = "0";
                                 document.getElementById('otkrb').style.display = "block";
            document.getElementById('pk8').style.display = "none";
			});    
                                    
                                    
                         			document.getElementById("pkdd10").addEventListener("click", function() {
				document.getElementById("task").style.display = 'block';
				document.getElementById("otkrnt").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('taskmgr').style.Position = "fixed";
            document.getElementById('task').style.left = "0";
            document.getElementById('task').style.top = "0";
         
			});    
                                    
                         			document.getElementById("pkdd11").addEventListener("click", function() {
				document.getElementById("pass2").style.display = 'block';
				document.getElementById("otkrprov").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('pass2').style.Position = "fixed";
            document.getElementById('pass2').style.left = "0";
            document.getElementById('pass2').style.top = "0";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd12").addEventListener("click", function() {
				document.getElementById("str").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('str').style.Position = "fixed";
            document.getElementById('str').style.left = "0";
            document.getElementById('str').style.top = "0";
                                    document.getElementById('otkrstr').style.display = "block";
            document.getElementById('pk10').style.display = "none";
         
			});    
                                    
                                    
                         			document.getElementById("pkdd13").addEventListener("click", function() {
				document.getElementById("cam").style.display = 'block';
				document.getElementById("otkrcam").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('cam').style.Position = "fixed";
            document.getElementById('cam').style.left = "0";
            document.getElementById('cam').style.top = "0";
         
			});    
                                    
                                    
                                    
                         			document.getElementById("pkdd15").addEventListener("click", function() {
				document.getElementById("player").style.display = 'block';
				document.getElementById("otkrplay").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('player').style.Position = "fixed";
            document.getElementById('player').style.left = "0";
            document.getElementById('player').style.top = "0";
         
			});    
                                    

                         			document.getElementById("pkdd16").addEventListener("click", function() {
				document.getElementById("winwer").style.display = 'block';
				document.getElementById("otkrwin").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('winwer').style.Position = "fixed";
            document.getElementById('winwer').style.left = "0";
            document.getElementById('winwer').style.top = "0";
         
			});    

                         			document.getElementById("pkdd14").addEventListener("click", function() {
				document.getElementById("PodderDiv").style.display = 'block';
				document.getElementById("PodderDiv").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('PodderDiv').style.Position = "fixed";
            document.getElementById('PodderDiv').style.left = "0";
            document.getElementById('PodderDiv').style.top = "0";
			document.getElementById("otkrpod").style.display = 'block';

			});
									                         			document.getElementById("pkdd17").addEventListener("click", function() {
				document.getElementById("regedit").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
				document.getElementById("otkrred").style.display = 'block';
                                    document.getElementById('regedit').style.Position = "fixed";
            document.getElementById('regedit').style.left = "0";
            document.getElementById('regedit').style.top = "0";

			});
																											                         			document.getElementById("pkdd18").addEventListener("click", function() {
				document.getElementById("telefon").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';

document.getElementById("otkrmessage").style.display = 'block';
			});
																																													                         			document.getElementById("pkdd19").addEventListener("click", function() {
				document.getElementById("bud").style.display = 'block';
				document.getElementById("otkrkalend").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';
                                    document.getElementById('bud').style.Position = "fixed";
            document.getElementById('bud').style.left = "0";
            document.getElementById('bud').style.top = "0";

			});
																																											document.getElementById("pkdd20").addEventListener("click", function() {
				document.getElementById("vi").style.display = 'block';
				document.getElementById("otkrvi").style.display = 'block';
                document.getElementById("poi").style.left = '-620px';

			});
		                         			document.getElementById("pkd19").addEventListener("click", function() {
				document.getElementById("winwer").style.display = 'block';
				document.getElementById("otkrwin").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('winwer').style.Position = "fixed";
            document.getElementById('winwer').style.left = "0";
            document.getElementById('winwer').style.top = "0";

			});
													                         			document.getElementById("pkd20").addEventListener("click", function() {
				document.getElementById("vi").style.display = 'block';
				document.getElementById("otkrvi").style.display = 'block';
                document.getElementById("mp").style.display = 'none';

			});
document.getElementById("fg").addEventListener("click", function() {
localStorage.removeItem('bo');
localStorage.removeItem('bo2');
localStorage.removeItem('gad');
localStorage.removeItem('passw');
localStorage.removeItem('us');
localStorage.removeItem('install');
localStorage.removeItem('col');
localStorage.removeItem('tem');
localStorage.removeItem('user');
localStorage.removeItem('par');
localStorage.removeItem('volume');
    localStorage.setItem('podder1', 0);
			});  
                         
                                


        
        
        

        
//                          			document.getElementById("pkddd1").addEventListener("click", function() {
// 				document.getElementById("pyuse").style.display = 'block';
//                 document.getElementById("mp").style.display = 'none';
//                                     document.getElementById('pyuse').style.Position = "fixed";
//             document.getElementById('pyuse').style.left = "0";
//             document.getElementById('pyuse').style.top = "0";
//
// 			});
                                    
                         			document.getElementById("pkddd2").addEventListener("click", function() {
				document.getElementById("ControlPanel").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('ControlPanel').style.Position = "fixed";
            document.getElementById('ControlPanel').style.left = "0";
            document.getElementById('ControlPanel').style.top = "0";
			document.getElementById("otkrpers").style.display = 'block';
			document.getElementById("pk7").style.display = 'none';
         
			});    
                                    
                                    
                         			document.getElementById("pkddd3").addEventListener("click", function() {
				document.getElementById("pass2").style.display = 'block';
				document.getElementById("otkrprov").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('pass2').style.Position = "fixed";
            document.getElementById('pass2').style.left = "0";
            document.getElementById('pass2').style.top = "0";
         
			});    

                         			document.getElementById("pkddd4").addEventListener("click", function() {
                       				document.getElementById("PodderDiv").style.display = 'block';
				document.getElementById("otkrpod").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
                                    document.getElementById('PodderDiv').style.Position = "fixed";
            document.getElementById('PodderDiv').style.left = "0";
            document.getElementById('PodderDiv').style.top = "0";
         
			});    

                         			document.getElementById("pkddd5").addEventListener("click", function() {
				document.getElementById("vi").style.display = 'block';
                document.getElementById("mp").style.display = 'none';
				document.getElementById('otkrvi').style.display = 'block';
         
			});



	var l222;
 l222 = 0;

 document.getElementById('fileb').style.display = "none";


 document.getElementById('otkfileb').addEventListener('click', function() {
 l222++;
 if(l222 > 2) {
 l222 = 1;
 }
 if(l222 == 1) {

    document.getElementById('fileb').style.display = "block";





 }
 else if (l222 == 2) {
document.getElementById('fileb').style.display = "none";
 }
 });




// 									                         			document.getElementById("otksprb").addEventListener("click", function() {
// 				document.getElementById("sprb").style.display = 'block';
// document.getElementById("fileb").style.display = 'none';
// 			});
// 																											                         			document.getElementById("otkfileb").addEventListener("click", function() {
// 				document.getElementById("fileb").style.display = 'block';
// document.getElementById("sprb").style.display = 'none';
// 			});
                     			document.getElementById("pers4").addEventListener("click", function() {
				document.getElementById("pers2").style.display = 'block';
				document.getElementById("nazadpy1").style.display = 'block';
                document.getElementById("StartPage").style.display = 'none';

			});

											             			document.getElementById("nazadpy1").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'none';
				document.getElementById("nazadpy1").style.display = 'none';
				document.getElementById("pers2").style.display = 'none';
                document.getElementById("StartPage").style.display = 'block';

			});
								            			document.getElementById("pyuse3").addEventListener("click", function() {
				document.getElementById("pyuse").style.display = 'block';
				document.getElementById("nazadpy1").style.display = 'block';
                document.getElementById("StartPage").style.display = 'none';

			});
					                  			document.getElementById("knpoisk").addEventListener("click", function() {
													   document.getElementById("mp").style.display = 'none';

				document.getElementById("poi").style.left = '0';




			});

					                  			document.getElementById("spravka").addEventListener("click", function() {
				document.getElementById("spravka2").style.display = 'block';


			});

					                  			document.getElementById("spravka3").addEventListener("click", function() {
				document.getElementById("spravka2").style.display = 'none';


			});
			document.getElementById("telefon2").addEventListener("click", function() {
document.getElementById('otkrmessage').style.display = "none";
				document.getElementById("telefon").style.display = 'none';

			});
						document.getElementById("PodderDiv2").addEventListener("click", function() {
document.getElementById('otkrpod').style.display = "none";
				document.getElementById("PodderDiv").style.display = 'none';

			});
                        					                  			document.getElementById("regedit2").addEventListener("click", function() {
				document.getElementById("regedit").style.display = 'none';
document.getElementById('otkrred').style.display = "none";

			});
                                  			document.getElementById("v4").addEventListener("click", function() {
												document.getElementById('audio3').play();
												document.getElementById("vets3").style.opacity = "0";
				document.getElementById('vets3').style.display = "block";
				document.getElementById("vets3").style.transition = "1s";
  window.setTimeout(function(){
document.getElementById("vets3").style.transition = "1s";
document.getElementById("vets3").style.opacity = "100%";
  }, 200);
  window.setTimeout(function(){
	  document.getElementById('page').style.display = "none";
  }, 1000);


			});                                 
				document.getElementById("vets3").addEventListener("click", function() {

				document.getElementById('audio4').play();
				document.getElementById("vets3").style.transition = "0";
                document.getElementById("vets3").style.display = 'none';
				document.getElementById("vets").style.display = 'block';
 document.getElementById('curtt').style.display = "block";
  window.setTimeout(function(){
document.getElementById("curtt").style.transition = "1s";
document.getElementById("curtt").style.opacity = "100%";
  }, 1500);
  window.setTimeout(function(){
document.getElementById("vets").style.display = "none";
  }, 2500);
  window.setTimeout(function(){
document.getElementById('page').style.display = "block";
document.getElementById("curtt").style.transition = "1s";
document.getElementById("curtt").style.opacity = "0";
  window.setTimeout(function(){
document.getElementById("curtt").style.display = "none";
  }, 1500);
  }, 3000);
			});                         
                                    

                                            });   
