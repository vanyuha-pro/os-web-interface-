

mouseX8 = 0;
      mouseY8 = 0;
      shiftX8 = 0;
      shiftY8 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX8 = e2.clientX;
        mouseY8 = e2.clientY;
      });
      
      o = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('ControlPanel2').addEventListener('mousedown', function(e2) {
          o = true;
          x = parseInt(document.getElementById('ControlPanel').style.left);
          y = parseInt(document.getElementById('ControlPanel').style.top);
          shiftX8 = e2.clientX - x;
          shiftY8 = e2.clientY - y;
        });
        anim8();
      });
      
      document.addEventListener('mouseup', function() { o = false });
      

      
      function anim8() {
        
        if(o) {
          document.getElementById('ControlPanel').style.left = (mouseX8-shiftX8) + 'px';
          document.getElementById('ControlPanel').style.top = (mouseY8-shiftY8) + 'px';
        }
        
        window.setTimeout(function() { anim8() }, 40);
      }
 mouseX9 = 0;
       mouseY9 = 0;
       shiftX9 = 0;
       shiftY9 = 0;
       document.addEventListener('mousemove', function(e2) {
         //console.log(e);

         mouseX9 = e2.clientX;
         mouseY9 = e2.clientY;
       });

       j = false;

       document.addEventListener('DOMContentLoaded', function() {
         document.getElementById('regedit3').addEventListener('mousedown', function(e2) {
           j = true;
           x = parseInt(document.getElementById('regedit').style.left);
           y = parseInt(document.getElementById('regedit').style.top);
           shiftX9 = e2.clientX - x;
           shiftY9 = e2.clientY - y;
         });
         anim9();
       });

       document.addEventListener('mouseup', function() { j = false });



       function anim9() {

         if(j) {
           document.getElementById('regedit').style.left = (mouseX9-shiftX9) + 'px';
           document.getElementById('regedit').style.top = (mouseY9-shiftY9) + 'px';
         }

         window.setTimeout(function() { anim9() }, 40);
       }


      
      
      
      mouseX13 = 0;
      mouseY13 = 0;
      shiftX13 = 0;
      shiftY13 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX13 = e2.clientX;
        mouseY13 = e2.clientY;
      });
      
      okl = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('str3').addEventListener('mousedown', function(e2) {
          okl = true;
          x = parseInt(document.getElementById('str').style.left);
          y = parseInt(document.getElementById('str').style.top);
          shiftX13 = e2.clientX - x;
          shiftY13 = e2.clientY - y;
        });
        anim13();
      });
      
      document.addEventListener('mouseup', function() { okl = false });
      

      
      function anim13() {
        
        if(okl) {
          document.getElementById('str').style.left = (mouseX13-shiftX13) + 'px';
          document.getElementById('str').style.top = (mouseY13-shiftY13) + 'px';
        }
        
        window.setTimeout(function() { anim13() }, 40);
      }
      
      
      
      
      mouseX14 = 0;
      mouseY14 = 0;
      shiftX14 = 0;
      shiftY14 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX14 = e2.clientX;
        mouseY14 = e2.clientY;
      });
      
      okk = false;
      
      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('player3').addEventListener('mousedown', function(e2) {
          okk = true;
          x = parseInt(document.getElementById('player').style.left);
          y = parseInt(document.getElementById('player').style.top);
          shiftX14 = e2.clientX - x;
          shiftY14 = e2.clientY - y;
        });
        anim14();
      });
      
      document.addEventListener('mouseup', function() { okk = false });
      

      
      function anim14() {
        
        if(okk) {
          document.getElementById('player').style.left = (mouseX14-shiftX14) + 'px';
          document.getElementById('player').style.top = (mouseY14-shiftY14) + 'px';
        }
        
        window.setTimeout(function() { anim14() }, 40);
      }

      mouseX25 = 0;
      mouseY25 = 0;
      shiftX25 = 0;
      shiftY25 = 0;
      document.addEventListener('mousemove', function(e2) {
        //console.log(e);

        mouseX25 = e2.clientX;
        mouseY25 = e2.clientY;
      });

      okkkk = false;

      document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('PodderDiv3').addEventListener('mousedown', function(e2) {
          okkkk = true;
          x = parseInt(document.getElementById('PodderDiv').style.left);
          y = parseInt(document.getElementById('PodderDiv').style.top);
          shiftX25 = e2.clientX - x;
          shiftY25 = e2.clientY - y;
        });
        anim25();
      });

      document.addEventListener('mouseup', function() { okkkk = false });



      function anim25() {

        if(okkkk) {
          document.getElementById('PodderDiv').style.left = (mouseX25-shiftX25) + 'px';
          document.getElementById('PodderDiv').style.top = (mouseY25-shiftY25) + 'px';
        }

        window.setTimeout(function() { anim25() }, 40);
      }
