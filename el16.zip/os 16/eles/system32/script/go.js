
document.addEventListener('DOMContentLoaded', function() {
document.getElementById("aktpb").addEventListener('click',function() {
v = document.getElementById("aktp").value;
if(v == "X57990AP7K8C125DLl07j5") {
    window.setTimeout(function() {
    document.getElementById('aud').play();
    document.getElementById("aktp").style.display = 'none';
    document.getElementById("aktpb").style.display = 'none';
    document.getElementById("nag2").value="657826";
         localStorage.setItem('nn3', document.getElementById('nag2').value);
     localStorage.setItem('nn', document.getElementById('aktpb').style.display);
      localStorage.setItem('nn2', document.getElementById('aktp').style.display);
    },500);
}
});
});
